# Description

The resource allows you to configure a computer by changing its name and
description and modifying its Active Directory domain or workgroup membership.
